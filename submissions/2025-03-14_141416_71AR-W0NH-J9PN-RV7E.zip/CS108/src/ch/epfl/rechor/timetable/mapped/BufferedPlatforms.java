package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.Platforms;

import java.nio.ByteBuffer;
import java.util.List;

public final class BufferedPlatforms implements Platforms {


    private static final int NAME_ID_OFFSET = 0;
    private static final int STATION_ID_OFFSET = 1;

    private final List<String> stringTable;
    private final StructuredBuffer buffer;

    private final static Structure STRUCTURE = new Structure(
            Structure.field(NAME_ID_OFFSET, Structure.FieldType.U16),
            Structure.field(STATION_ID_OFFSET, Structure.FieldType.U16)
    );

    public BufferedPlatforms(List<String> stringTable, ByteBuffer buffer){
        this.buffer = new StructuredBuffer(STRUCTURE, buffer);
        this.stringTable = stringTable;
    }

    private void checkIndex(int id) {
        if (id < 0 || id >= size()) {
            throw new IndexOutOfBoundsException();
        }
    }

    @Override
    public String name(int id) {
        checkIndex(id);
        return stringTable.get(buffer.getU16(NAME_ID_OFFSET, id));
    }

    @Override
    public int stationId(int id) {
        checkIndex(id);
        return buffer.getU16(STATION_ID_OFFSET, id);
    }

    @Override
    public int size() {
        return buffer.size();
    }
}
