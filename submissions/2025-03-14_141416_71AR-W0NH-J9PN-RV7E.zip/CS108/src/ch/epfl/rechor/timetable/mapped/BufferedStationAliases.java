package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.StationAliases;

import java.nio.ByteBuffer;
import java.util.List;

public final class BufferedStationAliases implements StationAliases {

    private final List<String> stringTable;
    private final StructuredBuffer buffer;


    public static final int ALIAS_FIELD_INDEX = 0;
    public static final int STATION_NAME_FIELD_INDEX = 1;

    public static final Structure STRUCTURE = new Structure(
            Structure.field(ALIAS_FIELD_INDEX, Structure.FieldType.U16),
            Structure.field(STATION_NAME_FIELD_INDEX, Structure.FieldType.U16)
    );

    public BufferedStationAliases(List<String> stringTable, ByteBuffer buffer) {
        this.buffer = new StructuredBuffer(STRUCTURE, buffer);
        this.stringTable = stringTable;
    }

    private void checkIndex(int id) {
        if (id < 0 || id >= size()) {
            throw new IndexOutOfBoundsException();
        }
    }

    @Override
    public String alias(int id) {
        checkIndex(id);
        int index = buffer.getU16(ALIAS_FIELD_INDEX, id);
        return stringTable.get(index);
    }

    @Override
    public String stationName(int id) {
        checkIndex(id);
        int index = buffer.getU16(STATION_NAME_FIELD_INDEX, id);
        return stringTable.get(index);
    }

    @Override
    public int size() {
        return buffer.size();
    }
}
