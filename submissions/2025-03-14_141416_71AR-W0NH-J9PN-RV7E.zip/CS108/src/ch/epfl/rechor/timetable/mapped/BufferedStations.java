package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.Stations;

import java.nio.ByteBuffer;
import java.util.List;

public final class BufferedStations implements Stations {


    private static final int NAME_ID_OFFSET = 0;
    private static final int LON_OFFSET = 1;
    private static final int LAT_OFFSET = 2;

    private static final double COORD_CONVERSION = Math.scalb(360, -32);

    private final List<String> stringTable;
    private final StructuredBuffer buffer;

    private final static Structure STRUCTURE = new Structure(
            Structure.field(NAME_ID_OFFSET, Structure.FieldType.U16),
            Structure.field(LON_OFFSET, Structure.FieldType.S32),
            Structure.field(LAT_OFFSET, Structure.FieldType.S32)
    );

    public BufferedStations(List<String> stringTable, ByteBuffer buffer) {
        this.stringTable = stringTable;
        this.buffer = new StructuredBuffer(STRUCTURE, buffer);
    }

    private void checkIndex(int id) {
        if (id < 0 || id >= size()) {
            throw new IndexOutOfBoundsException();
        }
    }

    @Override
    public String name(int id) {
        checkIndex(id);
        return stringTable.get(buffer.getU16(NAME_ID_OFFSET, id));
    }

    @Override
    public double longitude(int id) {
        checkIndex(id);
      return buffer.getS32(LON_OFFSET, id) * COORD_CONVERSION;
    }

    @Override
    public double latitude(int id) {
        checkIndex(id);
        return buffer.getS32(LAT_OFFSET, id) * COORD_CONVERSION;
    }


    @Override
    public int size(){
        return buffer.size();
    }
}