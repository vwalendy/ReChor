package ch.epfl.rechor.timetable.mapped;

import java.util.Objects;

public class Structure {


    public enum FieldType {
        U8, U16, S32;
    }

    public record Field(int index, FieldType type) {
        public Field {
            Objects.requireNonNull(type);
        }
    }

    public static Field field(int index, FieldType type) {
        return new Field(index, type);
    }

    private final Field[] fields;

    public Structure(Field... fields) {
        for (int i = 0; i < fields.length; i++) {
            if (fields[i].index() != i) {
                throw new IllegalArgumentException();
            }
        }
        this.fields = fields;
    }

    public int totalSize(){
        int size = 0;
        for (Field f : fields) {
            switch (f.type()) {
                case U8:
                    size += 1;
                    break;
                case U16:
                    size += 2;
                    break;
                case S32:
                    size += 4;
                    break;
                default:
                    throw new IllegalStateException();
            }
        }
        return size;
    }

    public int offset(int fieldIndex, int elementIndex){
        if (fieldIndex < 0 || fieldIndex >= fields.length){
            throw new IndexOutOfBoundsException();
        }
        if (elementIndex < 0){
            throw new IndexOutOfBoundsException();
        }
        int fieldOffset = 0;
        for (int i = 0; i < fieldIndex; i++){
            switch (fields[i].type()){
                case U8:
                    fieldOffset += 1;
                    break;
                case U16:
                    fieldOffset += 2;
                    break;
                case S32:
                    fieldOffset += 4;
                    break;
                default:
                    throw new IllegalStateException();
            }
        }
        return elementIndex * totalSize() + fieldOffset;
    }
}